package com.pbm.trading;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
